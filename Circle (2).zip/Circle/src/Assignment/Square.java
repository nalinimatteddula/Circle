package Assignment;

public class Square extends Shape {
	
	
	public Square(float length) {
		super(length);
		// TODO Auto-generated constructor stub
	}

	public void squareArea() {
		float area = length*length;
		System.out.println("Area of the square :"+area);
	}
	
	public void squarePerimeter() {
		float perimeter = 4*length;
		System.out.println("Perimeter of the square:"+perimeter);
	}

}
