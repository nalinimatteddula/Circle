package activity;

public class Rectangle {
	float length;
	float width;
	
	public Rectangle(float length, float width) {
		super();
		this.length = length;
		this.width = width;
	}

	public Rectangle() {
		
	}
	
	public void area() {
		float area = length*width;
		   System.out.println("Area :"+area);
		}
		
	
	
	public void perimeter() {
		float perimeter = 2*(length+width);
		System.out.println("perimeter:"+perimeter);
		
	}

}
