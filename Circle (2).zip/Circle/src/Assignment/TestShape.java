package Assignment;

public class TestShape{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Rectangle rec = new Rectangle(2,3);
		System.out.println("Area and perimeter of the rectangle: ");
		System.out.println("Length :"+rec.length);
		System.out.println("Width :"+rec.width);
		rec.rectangleArea();
		rec.rectanglePerimeter();
		System.out.println("");
		
		Square square = new Square(2);
		System.out.println("Area and perimeter of the square :");
		System.out.println("Length :"+square.length);
		square.squareArea();
		square.squarePerimeter();
		System.out.println("");
		
		Rhombus rhom = new Rhombus(2, 3);
		System.out.println("Area and Perimeter of the rhombus :");
		System.out.println("Length :"+rhom.length);
		System.out.println("height :"+rhom.height);
        rhom.rhombusArea();
        rhom.rhombusPerimeter();
         
	}
}
