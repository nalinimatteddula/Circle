package activity;

public class act {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Circle cir = new Circle(10);
	System.out.println("radius :"+cir.radius);
	System.out.println("diameter :"+cir.diameter);
	cir.area();
	cir.circumference();
	
	}
}

