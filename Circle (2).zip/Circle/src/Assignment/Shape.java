package Assignment;

public class Shape {
	float length;

	public Shape(float length) {
		super();
		this.length = length;
	}
	
	
}
