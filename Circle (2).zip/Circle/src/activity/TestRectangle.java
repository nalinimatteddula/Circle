package activity;

public class TestRectangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Rectangle rec = new Rectangle(2,4);
		System.out.println("length :"+rec.length);
		System.out.println("width :"+rec.width);
		rec.area();
		rec.perimeter();

	}

}
