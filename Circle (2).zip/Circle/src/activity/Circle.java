package activity;

public class Circle {
	
		float radius;
		final static float piValue  = 3.14f;
		float diameter;
		public Circle(float radius) {
			super();
			this.radius = radius;
			this.diameter = radius *2;
		}

	
public Circle() {
	
}

public void area() {
	float area = piValue*radius*radius;
   System.out.println("Area :"+area);
}

public void circumference() {
	float circumference = 2*piValue*radius;
	   System.out.println("circumference :"+circumference);
	}
}


