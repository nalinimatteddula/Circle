package Assignment;


public class Rectangle extends Shape {
	float width;
	public Rectangle(float length) {
		super(length);
		// TODO Auto-generated constructor stub
	}


	public Rectangle(float length, float width) {
		super(length);
		this.width = width;
	}

	public void rectangleArea() {
		float area = length*width;
		   System.out.println("Area :"+area);
		}
		
	public void rectanglePerimeter() {
		float perimeter = 2*(length+width);
		System.out.println("perimeter:"+perimeter);
		
		
	}
	
	
}
