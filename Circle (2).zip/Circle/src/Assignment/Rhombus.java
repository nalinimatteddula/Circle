package Assignment;

public class Rhombus extends Shape {
	float height;
	public Rhombus(float length, float height) {
		super(length);
		this.height = height;
	}


	public Rhombus(float length) {
		super(length);
		// TODO Auto-generated constructor stub
	}

	public void rhombusArea() {
		float area = length*height;
		System.out.println("Area of the rhombus: "+area);
		
	}
	
	public void rhombusPerimeter() {
		float perimeter = 4 *length;
		System.out.println("Perimeter of the rhombus: "+perimeter);
	}

}
